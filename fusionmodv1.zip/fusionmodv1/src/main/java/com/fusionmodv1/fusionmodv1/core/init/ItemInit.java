package com.fusionmodv1.core.init;

import com.fusionmodv1.FusionModV1;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ItemInit {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, FusionModV1.MOD_ID);
    
    private static RegistryObject<Item> register(String name) { 
        return ITEMS.register(name, () -> new Item(new Item.Properties())); 
    }

    public static final RegistryObject<Item> FUSION_TABLE = ITEMS.register("fusion_table", 
        () -> new BlockItem(BlockInit.FUSION_TABLE.get(), new Item.Properties()));
    
    public static final RegistryObject<Item> REINFORCED_STONE_SWORD = register("reinforced_stone_sword");
    public static final RegistryObject<Item> FAINTLY_GLOWING_STONE = register("faintly_glowing_stone");
    public static final RegistryObject<Item> STURDY_SHIELD = register("sturdy_shield");
    public static final RegistryObject<Item> COMPRESSED_COBBLESTONE = register("compressed_cobblestone");
    public static final RegistryObject<Item> BLANK_RUNE = register("blank_rune");
    public static final RegistryObject<Item> QUILL_OF_POWER = register("quill_of_power");
    public static final RegistryObject<Item> AETHERIUM_INGOT = register("aetherium_ingot");
    public static final RegistryObject<Item> SOULFORGED_STEEL_INGOT = register("soulforged_steel_ingot");
    public static final RegistryObject<Item> STABILIZED_GUNPOWDER = register("stabilized_gunpowder");
    public static final RegistryObject<Item> HARDENED_LEATHER = register("hardened_leather");
    public static final RegistryObject<Item> ARCANE_QUARTZ = register("arcane_quartz");
    public static final RegistryObject<Item> BLAST_RESISTANT_PLATING = register("blast_resistant_plating");
    public static final RegistryObject<Item> AQUATIC_CORE = register("aquatic_core");
    public static final RegistryObject<Item> STORM_CORE = register("storm_core");
    public static final RegistryObject<Item> VERDANT_ESSENCE = register("verdant_essence");
    public static final RegistryObject<Item> VOID_SHARD = register("void_shard");
    public static final RegistryObject<Item> IRON_DRILL = register("iron_drill");
    public static final RegistryObject<Item> GOLD_DRILL = register("gold_drill");
    public static final RegistryObject<Item> DIAMOND_DRILL = register("diamond_drill");
    public static final RegistryObject<Item> NETHERITE_DRILL = register("netherite_drill");
    public static final RegistryObject<Item> OBSIDIAN_DRILL = register("obsidian_drill");
    public static final RegistryObject<Item> ENDER_DRILL = register("ender_drill");
    public static final RegistryObject<Item> EXCAVATOR_SHOVEL = register("excavator_shovel");
    public static final RegistryObject<Item> LUMBER_AXE = register("lumber_axe");
    public static final RegistryObject<Item> BROAD_AXE = register("broad_axe");
    public static final RegistryObject<Item> VEIN_MINER_PICKAXE = register("vein_miner_pickaxe");
    public static final RegistryObject<Item> REAPER_SCYTHE = register("reaper_scythe");
    public static final RegistryObject<Item> BUILDER_S_WAND = register("builder_s_wand");
    public static final RegistryObject<Item> GRAPPLING_HOOK = register("grappling_hook");
    public static final RegistryObject<Item> INFINITY_BACKPACK = register("infinity_backpack");
    public static final RegistryObject<Item> VOIDER_MODULE = register("voider_module");
    public static final RegistryObject<Item> CAPACITY_UPGRADE_SMALL = register("capacity_upgrade_small");
    public static final RegistryObject<Item> CRAFTING_UPGRADE = register("crafting_upgrade");
    public static final RegistryObject<Item> MINION_CORE = register("minion_core");
    public static final RegistryObject<Item> MINION_LINK_TOOL = register("minion_link_tool");
    public static final RegistryObject<Item> AUTO_SMELTER_UPGRADE = register("auto_smelter_upgrade");
    public static final RegistryObject<Item> SUPER_COMPACTOR_UPGRADE = register("super_compactor_upgrade");
    public static final RegistryObject<Item> DIAMOND_SPREADING_UPGRADE = register("diamond_spreading_upgrade");
    public static final RegistryObject<Item> GLIMMERING_CORE = register("glimmering_core");
    public static final RegistryObject<Item> CORRUPTED_PLATING = register("corrupted_plating");
    public static final RegistryObject<Item> UNSTABLE_CORE = register("unstable_core");
    public static final RegistryObject<Item> THE_EARTHSHAKER = register("the_earthshaker");
    public static final RegistryObject<Item> ABYSSAL_SCALE = register("abyssal_scale");
    public static final RegistryObject<Item> TRIDENT_OF_THE_DEPTHS = register("trident_of_the_depths");
    public static final RegistryObject<Item> HEART_OF_THE_VOID = register("heart_of_the_void");
    public static final RegistryObject<Item> VOID_SCALE = register("void_scale");
    public static final RegistryObject<Item> SINGULARITY_BLADE = register("singularity_blade");
    public static final RegistryObject<Item> THE_FINAL_SINGULARITY = register("the_final_singularity");
    public static final RegistryObject<Item> EVENT_HORIZON = register("event_horizon");
    public static final RegistryObject<Item> POCKET_UNIVERSE = register("pocket_universe");
    
    public static void register(IEventBus eventBus) { 
        ITEMS.register(eventBus); 
    }
}