package com.fusionmodv1.common.recipe;

import com.fusionmodv1.FusionModV1;
import com.fusionmodv1.core.init.RecipeInit;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

public class FusionRecipe implements Recipe<Container> {

    private final ResourceLocation id;
    private final Ingredient input1;
    private final Ingredient input2;
    private final Ingredient catalyst;
    private final ItemStack output;

    public FusionRecipe(ResourceLocation id, Ingredient input1, Ingredient input2, Ingredient catalyst, ItemStack output) {
        this.id = id;
        this.input1 = input1;
        this.input2 = input2;
        this.catalyst = catalyst;
        this.output = output;
    }

    public Ingredient getInput1() { return input1; }
    public Ingredient getInput2() { return input2; }
    public Ingredient getCatalyst() { return catalyst; }

    @Override
    public boolean matches(Container pContainer, Level pLevel) {
        if (pLevel.isClientSide()) return false;

        boolean inputsMatch = (input1.test(pContainer.getItem(0)) && input2.test(pContainer.getItem(1))) ||
                              (input1.test(pContainer.getItem(1)) && input2.test(pContainer.getItem(0)));
        boolean catalystMatches = catalyst.test(pContainer.getItem(2));

        return inputsMatch && catalystMatches;
    }

    @Override
    public ItemStack assemble(Container pContainer, RegistryAccess pRegistryAccess) {
        return output.copy();
    }

    @Override
    public boolean canCraftInDimensions(int pWidth, int pHeight) {
        return true;
    }

    @Override
    public ItemStack getResultItem(RegistryAccess pRegistryAccess) {
        return output.copy();
    }

    @Override
    public ResourceLocation getId() {
        return id;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return RecipeInit.FUSION_RECIPE_SERIALIZER.get();
    }

    @Override
    public RecipeType<?> getType() {
        return RecipeInit.FUSION_RECIPE_TYPE.get();
    }
    
    public static class Type implements RecipeType<FusionRecipe> {
        public static final Type INSTANCE = new Type();
        public static final ResourceLocation ID = new ResourceLocation(FusionModV1.MOD_ID, "fusion");
    }
}