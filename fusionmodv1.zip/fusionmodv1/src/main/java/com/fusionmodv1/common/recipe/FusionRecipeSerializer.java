package com.fusionmodv1.common.recipe;

import com.google.gson.JsonObject;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.ShapedRecipe;
import org.jetbrains.annotations.Nullable;

public class FusionRecipeSerializer implements RecipeSerializer<FusionRecipe> {

    @Override
    public FusionRecipe fromJson(ResourceLocation pRecipeId, JsonObject pSerializedRecipe) {
        Ingredient input1 = Ingredient.fromJson(GsonHelper.getAsJsonObject(pSerializedRecipe, "input1"));
        Ingredient input2 = Ingredient.fromJson(GsonHelper.getAsJsonObject(pSerializedRecipe, "input2"));
        Ingredient catalyst = Ingredient.EMPTY;
        if (pSerializedRecipe.has("catalyst")) {
            catalyst = Ingredient.fromJson(GsonHelper.getAsJsonObject(pSerializedRecipe, "catalyst"));
        }
        var output = ShapedRecipe.itemStackFromJson(GsonHelper.getAsJsonObject(pSerializedRecipe, "output"));

        return new FusionRecipe(pRecipeId, input1, input2, catalyst, output);
    }

    @Nullable
    @Override
    public FusionRecipe fromNetwork(ResourceLocation pRecipeId, FriendlyByteBuf pBuffer) {
        Ingredient input1 = Ingredient.fromNetwork(pBuffer);
        Ingredient input2 = Ingredient.fromNetwork(pBuffer);
        Ingredient catalyst = Ingredient.fromNetwork(pBuffer);
        var output = pBuffer.readItem();
        return new FusionRecipe(pRecipeId, input1, input2, catalyst, output);
    }

    @Override
    public void toNetwork(FriendlyByteBuf pBuffer, FusionRecipe pRecipe) {
        pRecipe.getInput1().toNetwork(pBuffer);
        pRecipe.getInput2().toNetwork(pBuffer);
        pRecipe.getCatalyst().toNetwork(pBuffer);
        pBuffer.writeItem(pRecipe.getResultItem(null));
    }
}