package com.fusionmodv1.common.block.entity;

import com.fusionmodv1.common.recipe.FusionRecipe;
import com.fusionmodv1.core.init.BlockEntityInit;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class FusionTableBlockEntity extends BlockEntity implements MenuProvider {
    private final ItemStackHandler itemHandler = new ItemStackHandler(4);

    private LazyOptional<IItemHandler> lazyItemHandler = LazyOptional.empty();

    public FusionTableBlockEntity(BlockPos pPos, BlockState pBlockState) {
        super(BlockEntityInit.FUSION_TABLE_ENTITY.get(), pPos, pBlockState);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.fusionmodv1.fusion_table");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int pContainerId, Inventory pPlayerInventory, Player pPlayer) {
        // We will create the actual Menu class later
        return null; 
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if(cap == ForgeCapabilities.ITEM_HANDLER) {
            return lazyItemHandler.cast();
        }
        return super.getCapability(cap, side);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        lazyItemHandler = LazyOptional.of(() -> itemHandler);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        lazyItemHandler.invalidate();
    }

    @Override
    protected void saveAdditional(CompoundTag pTag, HolderLookup.Provider pRegistries) {
        pTag.put("inventory", itemHandler.serializeNBT(pRegistries));
        super.saveAdditional(pTag, pRegistries);
    }

    @Override
    public void loadAdditional(CompoundTag pTag, HolderLookup.Provider pRegistries) {
        super.loadAdditional(pTag, pRegistries);
        itemHandler.deserializeNBT(pRegistries, pTag.getCompound("inventory"));
    }

    public void drops() {
        SimpleContainer inventory = new SimpleContainer(itemHandler.getSlots());
        for(int i = 0; i < itemHandler.getSlots(); i++) {
            inventory.setItem(i, itemHandler.getStackInSlot(i));
        }
        Containers.dropContents(this.level, this.worldPosition, inventory);
    }

    public static void tick(Level pLevel, BlockPos pPos, BlockState pState, FusionTableBlockEntity pBlockEntity) {
        if(pLevel.isClientSide()) {
            return;
        }

        if(hasRecipe(pBlockEntity)) {
            craftItem(pBlockEntity);
            pBlockEntity.setChanged();
        }
    }

    private static void craftItem(FusionTableBlockEntity entity) {
        Level level = entity.level;
        SimpleContainer inventory = new SimpleContainer(entity.itemHandler.getSlots());
        for (int i = 0; i < entity.itemHandler.getSlots(); i++) {
            inventory.setItem(i, entity.itemHandler.getStackInSlot(i));
        }

        Optional<FusionRecipe> recipeOpt = level.getRecipeManager()
                .getRecipeFor(FusionRecipe.Type.INSTANCE, inventory, level);

        if(recipeOpt.isPresent()) {
            FusionRecipe recipe = recipeOpt.get();
            // This logic correctly handles swapping input slots
            if (recipe.getInput1().test(entity.itemHandler.getStackInSlot(0))) {
                entity.itemHandler.extractItem(0, 1, false);
                entity.itemHandler.extractItem(1, 1, false);
            } else {
                entity.itemHandler.extractItem(1, 1, false);
                entity.itemHandler.extractItem(0, 1, false);
            }
            entity.itemHandler.extractItem(2, 1, false);

            entity.itemHandler.setStackInSlot(3, new ItemStack(recipe.getResultItem(level.registryAccess()).getItem(),
                    entity.itemHandler.getStackInSlot(3).getCount() + recipe.getResultItem(level.registryAccess()).getCount()));
        }
    }

    private static boolean hasRecipe(FusionTableBlockEntity entity) {
        Level level = entity.level;
        SimpleContainer inventory = new SimpleContainer(entity.itemHandler.getSlots());
        for (int i = 0; i < entity.itemHandler.getSlots(); i++) {
            inventory.setItem(i, entity.itemHandler.getStackInSlot(i));
        }

        Optional<FusionRecipe> recipeOpt = level.getRecipeManager()
                .getRecipeFor(FusionRecipe.Type.INSTANCE, inventory, level);

        if (recipeOpt.isEmpty()) {
            return false;
        }
        
        ItemStack result = recipeOpt.get().getResultItem(level.registryAccess());
        
        return canInsertAmountIntoOutputSlot(inventory, result.getCount()) &&
               canInsertItemIntoOutputSlot(inventory, result);
    }

    private static boolean canInsertItemIntoOutputSlot(SimpleContainer inventory, ItemStack stack) {
        return inventory.getItem(3).isEmpty() || inventory.getItem(3).is(stack.getItem());
    }

    private static boolean canInsertAmountIntoOutputSlot(SimpleContainer inventory, int count) {
        return inventory.getItem(3).getCount() + count <= inventory.getItem(3).getMaxStackSize();
    }
}