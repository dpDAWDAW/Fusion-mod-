package com.fusionmodv1;

import com.fusionmodv1.core.init.BlockInit;
import com.fusionmodv1.core.init.ItemInit;
import com.fusionmodv1.core.init.RecipeInit; // <-- Make sure this import is present
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(FusionModV1.MOD_ID)
public class FusionModV1 {
    public static final String MOD_ID = "fusionmodv1";

    public FusionModV1() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ItemInit.register(modEventBus);
        BlockInit.register(modEventBus);
        RecipeInit.register(modEventBus); // <-- Add this line

        MinecraftForge.EVENT_BUS.register(this);
    }
}